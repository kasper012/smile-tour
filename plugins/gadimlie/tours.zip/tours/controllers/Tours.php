<?php namespace Gadimlie\Tours\Controllers;

use BackendMenu;
use Backend\Classes\Controller;

/**
 * Tours Back-end Controller
 */
class Tours extends Controller
{
    /**
     * @var array Behaviors that are implemented by this controller.
     */
    public $implement = [
        'Backend.Behaviors.FormController',
        'Backend.Behaviors.ListController'
    ];

    /**
     * @var string Configuration file for the `FormController` behavior.
     */
    public $formConfig = 'config_form.yaml';

    /**
     * @var string Configuration file for the `ListController` behavior.
     */
    public $listConfig = 'config_list.yaml';

    public function __construct()
    {
        parent::__construct();

        BackendMenu::setContext('Gadimlie.Tours', 'tours', 'tours');
    }
}
